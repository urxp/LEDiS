#include"bin2inc.h"
#include<stdio.h>
#include<stdlib.h>

#ifdef BINARY_INFO
	#define GLOBAL_HEX
#endif

#define GLOBAL_STATS
#define GLOBAL_POSITIONS

#ifdef GLOBAL_STATS
	#include<sys/time.h>
#endif

extern dword fixups_counter;
extern object_info * ObjectMap;
extern FILE * fixup_fd;
extern DisasmInterface IDisasm;

char * indent = "";
dword fix_indent = 0;

dword GLOBAL_DB_MAX = 0x10;
#ifdef GLOBAL_POSITIONS
	dword GLOBAL_POSITIONS_INTERVAL = 0x080;
	dword GLOBAL_PAGE_SIZE = 0x1000;
#endif
const char * GLOBAL_LABEL_PREFIX = "$@";

#ifdef GLOBAL_STATS
struct timeval __global_timer, __local_timer;
qword global_timer, local_timer;

qword timeDiff(struct timeval * start){

	qword useconds0 = 1000000 * start->tv_sec + start->tv_usec;
    gettimeofday(&__local_timer, (void *)0);
	qword useconds1 = 1000000 * __local_timer.tv_sec + __local_timer.tv_usec;

	return useconds1 - useconds0;
}

char * formatTime(qword useconds){

	char * ft = calloc(32, 1);

	dword seconds0 = useconds / 1000000;
	dword mseconds0 = useconds / 1000 % 1000;
	dword useconds0 = useconds % 1000000;

	if(useconds < 10000){

		sprintf(ft, "%d.%03d ms", mseconds0, useconds0);

		return ft;
	}

	sprintf(ft, "%d.%03d s", seconds0, mseconds0);

	return ft;
}
#endif



char * getObjectSegmentMapName(dword object_n){

	return ObjectMap[object_n - 1].MapName;
}

char * getObjectMapName(dword object_n){

	return ObjectMap[object_n - 1].MapName;
}

dword getObjectSize(dword object_n){

	return ObjectMap[object_n - 1].size;
}

dword getObjectOffset(dword object_n){

	return ObjectMap[object_n - 1].offset;
}

dword getObjectSegmentBaseAddress(dword object_n){

	return ObjectMap[object_n - 1].RelBaseAddress;
}

boolean getEntryStatus(dword object_n, dword address){

	if(ObjectMap[object_n - 1].EntryAddress != -1){

		return boolean(address == -1)
		? boolean(1)
		: boolean(ObjectMap[object_n - 1].EntryAddress == address); 
	}

	return boolean(0);
}

dword getEntryAddress(dword object_n){

	if(getEntryStatus(object_n, -1)) return ObjectMap[object_n - 1].EntryAddress;

	return -1;
}

boolean hasBSS(dword object_n){

	return boolean(ObjectMap[object_n - 1].BSS);
}


char * formatAddress(dword value){

	char * addressStr = calloc(12, 1); 

	sprintf(addressStr, "%08x", value);

	return addressStr;
}




char * hexbyte(dword val){

	char * result = calloc(12, 1);
	char * result0 = calloc(12, 1);

	sprintf(result, "%x", val);

	if(val < 10) return result;

	while(val){

		if(((val > 15) && (val < 160))
		||(val < 10)){

			sprintf(result0, "%sh", result);
			sprintf(result, "%s", result0);
			return result;
		}
		
		val >>= 8;
	}

	sprintf(result0, "0%sh", result);
	sprintf(result, "%s", result0);
	
	return result;
}

char * getLabel(dword obj, dword offset){

	char * label;


	if(obj == 1){ // RALLY.LE specific
		switch(offset){
		case 0x00000003:
			return "___begtext";
		case 0x0004ea14:
			return "__CHK";
		case 0x0004ea9b:
			return "WATCOM_printf";
		case 0x00053f64:
			return "__GETDS";
		case 0x0005413e:
			return "WATCOM_fopen";
		case 0x000541f2:
			return "WATCOM_fread";
		case 0x000543cd:
			return "WATCOM_fclose";
		case 0x00055b5e:
			return "WATCOM_fwrite";
		default:
			break;
		}
	}

	label = calloc(32, 1);
	sprintf(label, "%s%s", GLOBAL_LABEL_PREFIX, hexbyte(getObjectSegmentBaseAddress(obj) + offset));

	return label;
}

#ifdef GLOBAL_STATS
char * speed(dword bytes, qword us){

	char * bspeed = calloc(32, 1);

	dword Ki = 1024;
	dword KB = Ki;
	dword MB = Ki*KB;
	dword GB = Ki*MB;

	double seconds_inverse = 1000000.0 / us;
	double speed_bs = seconds_inverse * bytes;

	if(speed_bs < (double)KB){
		sprintf(bspeed, "%.2f B/s", speed_bs);	
		return bspeed;
	}

	if(speed_bs < (double)MB){
		sprintf(bspeed, "%.2f KB/s", speed_bs / KB);	
		return bspeed;
	}

	if(speed_bs < (double)GB){
		sprintf(bspeed, "%.2f MB/s", speed_bs / MB);	
		return bspeed;
	}

	sprintf(bspeed, "%.2f GB/s", speed_bs / GB);	
	return bspeed;
}
#endif





void insert_dups(FILE * fd, dword qms){

	if(qms > 0) fprintf(fd, "resb\t%s\n", hexbyte(qms));
}
















struct {

	FILE * 		fd;
	dword 		obj_n;
	dword 		i;
	dword 		db_written;
	dword 		page_number;
	pointer 	in_buff;
} le;




void fn_fixup(){ // fixup

	dword diff;
	fixup_struct * fixup;

	fixup = le_getFixup(le.obj_n, le.i);

	switch(fixup->size){
	case 1:
		fprintf(le.fd, "\n%sdb\t%s", indent, getLabel(fixup->object_n, fixup->target));
		le.db_written++;
		break;
	case 2:
		if(fixup->type == 2){
			fprintf(le.fd, "\n%sdw\t%s", indent, getObjectSegmentMapName(fixup->object_n));
		}
		else {
			fprintf(le.fd, "\n%sdw\t%s", indent, getLabel(fixup->object_n, fixup->target));
		}
		le.i+=1;
		le.db_written = 0;
#ifdef GLOBAL_POSITIONS
		if(le.i % GLOBAL_PAGE_SIZE == 0) le.page_number++;
		if(le.i % GLOBAL_POSITIONS_INTERVAL == 0)
			fprintf(le.fd, "\n;%d:%s+1", le.page_number, formatAddress(getObjectSegmentBaseAddress(le.obj_n) + le.i));
#endif
		break;
	case 4:
		fprintf(le.fd, "\n%sdd\t%s", indent, getLabel(fixup->object_n, fixup->target));
		le.i+=3;
		le.db_written = 0;
#ifdef GLOBAL_POSITIONS
		if(le.i % GLOBAL_PAGE_SIZE < 3) le.page_number++;
		diff = le.i % GLOBAL_POSITIONS_INTERVAL;
		if(diff < 3)
			fprintf(le.fd, "\n;%d:%s+%d", le.page_number, formatAddress(getObjectSegmentBaseAddress(le.obj_n) + le.i - diff), 3 - diff);
#endif			
		break;
	default:
		printf("[bin2inc] err invalid fixup size %d\n", fixup->size);
	}
}


void fn_nofixup(){

	char indt[16];
	char * dlmtr;

	if(le.db_written % GLOBAL_DB_MAX != 0){
		dlmtr = ",";
	}
	else {
		sprintf(indt, "\n%sdb\t", indent);
		dlmtr = indt;
	}

	fprintf(le.fd, "%s%s", dlmtr, hexbyte(((byte *)le.in_buff)[le.i]));
	le.db_written++;
}

void fn_bytes(){

	char addr[16];
	char * dlmtr;

	if(le.db_written % GLOBAL_DB_MAX != 0){
		dlmtr = " ";
	}
	else {
		sprintf(addr,"\n;%08x: ", le.i);
		dlmtr = addr;
	};
	fprintf(le.fd, "%s%02x", dlmtr, ((byte *)le.in_buff)[le.i]);
	le.db_written++;
}

void (*f_fixup[2])(void) = { &fn_nofixup, &fn_fixup };

void fn_noinstruction(){

	f_fixup[!!(ObjectMap[le.obj_n - 1].IR[le.i].flags & 0x2)]();
}

void fn_instruction(){

	//indent = "";

	IDisasm.loadInstruction(ObjectMap[le.obj_n - 1].IR[le.i].data);

	dword le_i = le.i;

	dword skip;
	
	skip = (ObjectMap[le.obj_n - 1].IR[le.i].flags & 0xF0) >> 4;

	le.db_written = 0;
	while(skip--){
#ifdef GLOBAL_HEX
		fn_bytes();
#endif
		le.i++;
	}
	
	fix_indent = le.i;

	le.i = le_i;

	if(!!(ObjectMap[le.obj_n - 1].IR[le.i].flags & 0x8)){
		// comment out instruction, put raw bytes instead
		fprintf(le.fd, "\n\t\t;%s", IDisasm.InstructionString);
		le.db_written = 0;
		indent = "\t\t";
		fn_noinstruction();
	}
	else{
		
		skip = (ObjectMap[le.obj_n - 1].IR[le.i].flags & 0xF0) >> 4;
		le.i += (skip - 1);
		le.db_written = 0;

		fprintf(le.fd, "\n\t\t%s", IDisasm.InstructionString);
	}
}

void (*f_instruction[2])(void) = { &fn_noinstruction, &fn_instruction };

void fn_nolabel(){

	f_instruction[!!(ObjectMap[le.obj_n - 1].IR[le.i].flags & 0x4)]();
}

void fn_label(){

	fprintf(le.fd, "\n%s:", getLabel(le.obj_n, le.i));
	le.db_written = 0;

	fn_nolabel();
}


void (*f_label[2])(void) = { &fn_nolabel, &fn_label };





void bin2inc_2(dword obj_n, char * section_name){
	printf("[bin2inc] generating %s.inc\n", section_name);


	char filename[64] = {0};

	
	
	

	dword buff_size, qms, bss_end;

	if(hasBSS(obj_n)){

		buff_size	= le_getSize() - getObjectOffset(obj_n);
		bss_end 	= getObjectSize(obj_n);
	}
	else {		
		buff_size 	= getObjectSize(obj_n);
		bss_end		= 0;	
	}

	sprintf(filename, "%s.inc", section_name);

	le.in_buff 			= le_getBuffer() + getObjectOffset(obj_n);
	le.fd				= fopen(filename, "w");
	le.db_written		= 0;
	le.page_number		= 0;
	le.obj_n 			= obj_n;

	fprintf(le.fd, ";OBJECT#%d", obj_n);

//#ifdef GLOBAL_STATS
//	gettimeofday(&__local_timer, (void *)0);
//#endif

	for(le.i = 0; le.i < buff_size; le.i++){

		if(le.i == fix_indent){
			le.db_written = 0;
			indent = "";
		}
		
#ifdef GLOBAL_POSITIONS
		if(le.i % GLOBAL_PAGE_SIZE == 0) le.page_number++;

		if(le.i % GLOBAL_POSITIONS_INTERVAL == 0){
			
			fprintf(le.fd, "\n;%d:%s", le.page_number, formatAddress(getObjectSegmentBaseAddress(obj_n) + le.i));
			le.db_written = 0;
		}
#endif

		if(getEntryStatus(obj_n, le.i)){
		
			fprintf(le.fd, "\n..start:");
			le.db_written = 0;
		}

		f_label[ObjectMap[obj_n - 1].IR[le.i].flags & 0x1]();
	}

//#ifdef GLOBAL_STATS
//	local_timer = timeDiff(&__local_timer);
//	printf("          ... processed %u bytes in %s (%s)\n", buff_size, formatTime(local_timer), speed(buff_size, local_timer));
//#endif

	fclose(le.fd);

	if(bss_end != 0){

		sprintf(filename, "bss_%d.inc", obj_n);
		printf("[bin2inc] generating bss_%u.inc\n", obj_n);

		qms			= 0;
		le.fd		= fopen(filename, "w");

		fprintf(le.fd, ";UNINITIALIZED DATA\n");

//#ifdef GLOBAL_STATS
//		buff_size 	= bss_end - le.i;
//		gettimeofday(&__local_timer, (void *)0);
//#endif

		for(; le.i < bss_end; le.i++){

			if(le_checkLabel(obj_n, le.i)){

				insert_dups(le.fd, qms);
				qms = 0;

				fprintf(le.fd, "%s:\t", getLabel(obj_n, le.i));
			}

			qms++;
		}

//#ifdef GLOBAL_STATS
//		local_timer = timeDiff(&__local_timer);
//		printf("          ... processed %u bytes in %s (%s)\n", buff_size, formatTime(local_timer), speed(buff_size, local_timer));
//#endif

		insert_dups(le.fd, qms);
		fclose(le.fd);
	}



	dword codeBytes = ObjectMap[obj_n - 1].size - ObjectMap[obj_n - 1].DataBytes;

	double code_ratio = 100.0 * (double)ObjectMap[obj_n - 1].DisBytes / (double)codeBytes;
	double data_ratio = 100.0 * (double)ObjectMap[obj_n - 1].DataBytes / (double)ObjectMap[obj_n - 1].size;

	printf("          ... disassembled %u/%u bytes (%.3f %%)\n", ObjectMap[obj_n - 1].DisBytes, codeBytes, code_ratio);
	printf("          ... data %u/%u bytes (%.3f %%)\n", ObjectMap[obj_n - 1].DataBytes, ObjectMap[obj_n - 1].size, data_ratio);
}

























































int main(int argc, char * argv[]){

	dword object_n;

	fixup_fd = fopen("$__fixups.tmp", "wb+");
	IDisasm.init();

#ifdef GLOBAL_STATS
	gettimeofday(&__global_timer, (void *)0);
#endif

    le_initLinearExecutable("RALLY.LE");

    printf("[bin2inc] generating fixups and labels\n");

    processFixups();

	printf("          ... %d fixups\n", fixups_counter);
//#ifdef GLOBAL_STATS
//	local_timer = timeDiff(&__global_timer);
//	printf("          ... %d fixups in %s\n", fixups_counter, formatTime(local_timer));
//#endif


	// disassembling [TODO]
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0xdc });IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x534 });IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5a8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x754 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x11a4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x8774 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x15288 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x1a4f0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x1a558 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x2601c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x2a604 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x2a654 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x2aaf8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x2f78c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x2f7e4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x2f8ec });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x32148 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x328ec });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x33ea4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x350f4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x356c0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x3595c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x36758 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x392f4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x3933c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x39548 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x3e9a0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x43ad0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x46370 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x48c80 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x48cd8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x495d5 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x49621 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4966a });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x49682 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x496b6 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x496cb });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4a151 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4e118 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4f044 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4f4ac });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4f5a4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4f8a8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4f998 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4f9d8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4f9f8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x4fb6c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x500d6 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x50338 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5052f });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x506ca });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x506d2 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5072b });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5073f });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x50777 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x50a48 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x50a60 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x51a04 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x51b54 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x52704 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x528c4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x52970 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x52a1c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x52b34 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x53134 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x53168 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x53338 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x53388 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5345c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x534cc });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x53538 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x535c8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5386c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x54148 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x541b0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x54940 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x54974 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x54a7c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x54b60 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55284 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55408 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x554c4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55748 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x557d4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5583c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55884 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x558c0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x558c8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55970 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55978 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55980 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55988 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55b36 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55f3a });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x55f63 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5629c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x56383 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x563d7 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5658c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x56591 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x56596 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x565f2 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x56e84 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x56ea7 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x56fb4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x57230 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x57426 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x57521 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x57910 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x57b6c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x57b8c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x582d0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x58350 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x58684 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x586d4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x58780 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x587b8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5880c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x58c7e });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x594c0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x59923 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x59e53 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5d723 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5dbb1 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5de94 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e3a4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e3c0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e545 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e61b });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e620 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e624 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e655 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e65f });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e6a9 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5e8f5 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5eae5 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5eb1a });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5eb26 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5eb75 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5ecbb });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x5ef2c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x61da4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x65648 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x662dc });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x666c5 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x66e32 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6678e });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x67014 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x67741 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6786a });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x67db0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x67e47 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x67f2d });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6822b });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6823b });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x683ce });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x68517 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x688a0 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x688c4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x68910 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x68934 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x68a68 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x68aa4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6a5b2 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6a5b7 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6b694 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6b87b });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6b87c });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6bd1e });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6bee2 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6cdd4 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6d42e });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6d435 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6d912 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6d96e });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6dba8 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6dbe7 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6dd5e });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6de7f });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6de87 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6de93 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6de9f });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6e1e6 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6e335 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6eb11 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6eb24 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6ebbc });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6edd9 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6ee2e });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6ee8b });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6eefd });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6f148 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6f1c6 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6f289 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6f2e3 });
	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 1, .offset = 0x6f33a });

	IDisasm.pushAddress(&(VirtualAddress){ .obj_n = 2, .offset = 0 });

	pushJumpTable(&(VirtualAddress){ .obj_n = 1, .offset = 0x4fd6c });
	pushJumpTable(&(VirtualAddress){ .obj_n = 4, .offset = 0x1bbb0 });
	pushJumpTable(&(VirtualAddress){ .obj_n = 4, .offset = 0x1bc14 });

	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x3 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0xf });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x5e0 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x753 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x2f1f0 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x2f71b });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x486b0 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x48b1f });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x49e0f },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x4a0c1 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x4a22c },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x4e0db });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x4fbb6 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x4fd6b });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x4fdb4 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x4ff98 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x50420 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x50465 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x508b0 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x508eb });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x53c9a },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x53d0f });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x54720 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x54863 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x55d58 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x55d7c });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x577c0 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x577cb });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x588c0 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x58c41 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x58d30 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x591b7 });
	markAsData( // looks like table of interrupt call functions
		&(VirtualAddress){ .obj_n = 1, .offset = 0x5d7a4 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x5daa3 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x65f90 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x662db });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6813c },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x68160 });
		markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x68528 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x685df });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6a8c7 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6a946 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6aa7a },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6aad3 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6ae76 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6aebb });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6b0ea },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6b1af });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6b3cc },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6b3f3 });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6c8b0 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6c96f });
	markAsData(
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6e486 },
		&(VirtualAddress){ .obj_n = 1, .offset = 0x6e535 });

	IDisasm.disassemble();
	checkInfixLabels();

	// output

	for(object_n = 1; object_n <= le_getNumberOfObjects(); object_n++){
		
		bin2inc_2(object_n, getObjectMapName(object_n));
	}

#ifdef GLOBAL_STATS
	global_timer = timeDiff(&__global_timer);
	printf("[bin2inc] total time %s\n", formatTime(global_timer));
#endif

	IDisasm.close();
	fclose(fixup_fd);
	//remove("$__fixups.tmp");

    return 0;
}
