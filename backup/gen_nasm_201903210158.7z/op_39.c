#include"bin2inc.h"

#define TOBETHESAME

boolean op_39(void){

    address_mode = read_byte();

#if defined(TOBETHESAME)
    if((address_mode&0xc0) == 0xc0){

        char comment[256];
        char * __mod_rm;

        __mod_rm = mod_rm();

        sprintf(comment, iFORMAT"%s, %s", "cmp", __mod_rm, mod_reg());

        if(operand_size == 32){
            sprintf(ibuffer, ";%s\ndb\t39h, %s", comment, hexbyte(address_mode));
        }

        if(operand_size == 16){
            sprintf(ibuffer, ";%s\ndb\t66h, 39h, %s", comment, hexbyte(address_mode));
        }
    }
    else {
#endif
        sprintf(ibuffer, iFORMAT"%s, %s", "cmp", mod_rm(), mod_reg());
#if defined(TOBETHESAME)
    }
#endif

    mark_instruction();
    // push next instruction offset to stack
    IDisasm.pushAddress(&current_va);

    return boolean(1);
}