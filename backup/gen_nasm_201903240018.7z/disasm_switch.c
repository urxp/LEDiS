#include"bin2inc.h"



extern dword            disasm_ptr;


boolean prefix_66;
char ibuffer[256];
fixup_struct * fx;
char * seg_ds, * seg_ss, * seg_seg, * rep_prefix;
dword imm32, id;
char * tmp_str;
signed_byte displacement_8;
signed_word displacement_16;
signed_dword displacement_32;
byte operand_size;
byte address_size;
byte address_mode;

void disassemble(void){
#define FORMAT "%-8s"

    char * buffer = ibuffer;
    byte str_size;
    signed_dword rel32;
    signed_byte imm8, rel8;
    byte ib;
    word imm16, iw;
    

    while(IDisasm.popAddress()){

        if(checkAddress()) continue;

        seg_seg = "";
        seg_ds = "";
        seg_ss = "";
        rep_prefix = "";
        current_va = IDisasm.vAddress;
        operand_size = getBitsMode();
        address_size = operand_size;
        prefix_66 = boolean(0);

switch_start:
        switch(read_byte()){
        case 0x00:
            if(!op_00()) goto l_def;
            break;
        case 0x01:
            if(!op_01()) goto l_def;
            break;
        case 0x02:
            if(!op_02()) goto l_def;
            break;
        case 0x03:
            if(!op_03()) goto l_def;
            break;
        case 0x04:
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "add", "al", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x05:
            if(prefix_66){
                iw = read_word();
                sprintf(buffer, FORMAT"%s, %s", "add", "ax", hexbyte(iw));
            }
            else {
                id = read_dword();
                sprintf(buffer, FORMAT"%s, %s", "add", "eax", hexbyte(id));
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x06:
            sprintf(buffer, FORMAT"%s", "push", "es");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x07:
            sprintf(buffer, FORMAT"%s", "pop", "es");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x08:
            if(!op_08()) goto l_def;
            break;
        case 0x09:
            if(!op_09()) goto l_def;
            break;
        case 0x0a:
            if(!op_0a()) goto l_def;
            break;
        case 0x0b:
            if(!op_0b()) goto l_def;
            break;
        case 0x0c:
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "or", "al", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x0d:
            if(prefix_66){
                iw = read_word();
                sprintf(buffer, FORMAT"%s, %s", "or", "ax", hexbyte(iw));
            }
            else {
                id = read_dword();
                sprintf(buffer, FORMAT"%s, %s", "or", "eax", hexbyte(id));
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x0e:
            sprintf(buffer, FORMAT"%s", "push", "cs");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x0f:
            switch(read_byte()){
            case 0x82:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jb", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x84:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "je", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x85:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jne", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x86:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jbe", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x87:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "ja", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x8c:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jl", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x8d:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jge", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x8e:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jle", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x8f:
                rel32 = read_dword();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jg", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            case 0x94:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0xc2:
                    sprintf(buffer, FORMAT"%s", "setz", "dl");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            case 0x95:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0xc0:
                    sprintf(buffer, FORMAT"%s", "setnz", "al");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                case 0xc4:
                    sprintf(buffer, FORMAT"%s", "setnz", "ah");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            case 0x9e:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0xc0:
                    sprintf(buffer, FORMAT"%s", "setle", "al");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            case 0xa4:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0xc2:
                    ib = read_byte();
                    sprintf(buffer, FORMAT"%s, %s, %s", "shld", 
                        "edx", "eax", hexbyte(ib));
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                case 0xf0:
                    ib = read_byte();
                    sprintf(buffer, FORMAT"%s, %s, %s", "shld", 
                        "eax", "esi", hexbyte(ib));
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                case 0xf8:
                    ib = read_byte();
                    sprintf(buffer, FORMAT"%s, %s, %s", "shld", 
                        "eax", "edi", hexbyte(ib));
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            case 0xac:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0xd0:
                    ib = read_byte();
                    sprintf(buffer, FORMAT"%s, %s, %s", "shrd", 
                        "eax", "edx", hexbyte(ib));
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            case 0xaf:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0xc1:
                    sprintf(buffer, FORMAT"%s, %s", "imul", 
                        "eax", "ecx");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                case 0xd1:
                    sprintf(buffer, FORMAT"%s, %s", "imul", 
                        "edx", "ecx");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                case 0xfa:
                    sprintf(buffer, FORMAT"%s, %s", "imul", 
                        "edi", "edx");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            case 0xb6:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0x05:
                    fx = le_checkFixup(current_va.obj_n, current_va.offset);
                    id = read_dword();
                    if(fx->size == 4){
                        sprintf(buffer, FORMAT"%s, byte [%s%s]", "movzx",
                            "eax", seg_ds, getLabel(fx->object_n, fx->target));
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0x34:
                    if(read_byte() == 0x24){
                        sprintf(buffer, FORMAT"%s, byte [%s%s]",
                            "movzx", "esi", seg_ss, "esp");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0x3c:
                    if(read_byte() == 0x24){
                        sprintf(buffer, FORMAT"%s, byte [%s%s]",
                            "movzx", "edi", seg_ss, "esp");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0x3e:
                    sprintf(buffer, FORMAT"%s, byte [%s%s]",
                        "movzx", "edi", seg_ds, "esi");
                    mark_instruction(); comment_instruction();
                    IDisasm.pushAddress(&current_va);
                    break;
                case 0x6c:
                    if(read_byte() == 0x34){
                        displacement_8 = read_byte();
                        sprintf(buffer, FORMAT"%s, byte [%s%s+%s+%s]", "movzx",        "ebp", seg_ss, "esp", "esi", hexbyte(displacement_8));
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0x74:
                    if(read_byte() == 0x24){
                        displacement_8 = read_byte();
                        sprintf(buffer, FORMAT"%s, byte [%s%s+%s]",
                            "movzx", "esi", seg_ss, "esp", hexbyte(displacement_8));
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0x7c:
                    if(read_byte() == 0x34){
                        displacement_8 = read_byte();
                        sprintf(buffer, FORMAT"%s, byte [%s%s+%s+%s]", "movzx",        "edi", seg_ss, "esp", "esi", hexbyte(displacement_8));
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0xc0:
                    sprintf(buffer, FORMAT"%s, %s",
                            "movzx", "eax", "al");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    break;
                case 0xd8:
                    sprintf(buffer, FORMAT"%s, %s",
                            "movzx", "ebx", "al");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    break;
                case 0xe8:
                    sprintf(buffer, FORMAT"%s, %s",
                            "movzx", "ebp", "al");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    break;
                case 0xf0:
                    sprintf(buffer, FORMAT"%s, %s",
                            "movzx", "esi", "al");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    break;
                case 0xf3:
                    sprintf(buffer, FORMAT"%s, %s",
                            "movzx", "esi", "bl");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            case 0xb7:
                if(prefix_66) goto l_def;
                switch(read_byte()){
                case 0x05:
                    fx = le_checkFixup(current_va.obj_n, current_va.offset);
                    id = read_dword();
                    if(fx->size == 4){
                        sprintf(buffer, FORMAT"%s, word [%s%s]", "movzx",
                            "eax", seg_ds, getLabel(fx->object_n, fx->target));
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0x1d:
                    fx = le_checkFixup(current_va.obj_n, current_va.offset);
                    id = read_dword();
                    if(fx->size == 4){
                        sprintf(buffer, FORMAT"%s, word [%s%s]", "movzx",
                            "ebx", seg_ds, getLabel(fx->object_n, fx->target));
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    }
                    else goto l_def;
                    break;
                case 0xc0:
                    sprintf(buffer, FORMAT"%s, %s",
                            "movzx", "eax", "ax");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    break;
                case 0xc9:
                    sprintf(buffer, FORMAT"%s, %s",
                            "movzx", "ecx", "cx");
                        mark_instruction(); comment_instruction();
                        IDisasm.pushAddress(&current_va);
                    break;
                default:
                    goto l_def;
                }
                break;
            default:
                goto l_def;
            }
            break;
        case 0x19:
            switch(read_byte()){
            case 0xc0:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "sbb", "ax", "ax");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "sbb", "eax", "eax");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0x1e:
            sprintf(buffer, FORMAT"%s", "push", "ds");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x1f:
            sprintf(buffer, FORMAT"%s", "pop", "ds");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x20:
            if(!op_20()) goto l_def;            
            break;
        case 0x21:
            if(!op_21()) goto l_def;            
            break;
        case 0x22:
            if(!op_22()) goto l_def;            
            break;
        case 0x23:
            if(!op_23()) goto l_def;            
            break;
        case 0x24:
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "and", "al", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);     
            break;
        case 0x25:
            if(prefix_66){
                iw = read_word();
                sprintf(buffer, FORMAT"%s, %s", "and", "ax", hexbyte(iw));
            }
            else {
                id = read_dword();
                sprintf(buffer, FORMAT"%s, %s", "and", "eax", hexbyte(id));
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x26:
            seg_seg = "es:";
            seg_ds  = "es:";
            seg_ss  = "es:";
            goto switch_start;
        case 0x28:
            if(!op_28()) goto l_def;            
            break;
        case 0x29:
            if(!op_29()) goto l_def;            
            break;
        case 0x2a:
            if(!op_2a()) goto l_def;            
            break;
        case 0x2b:
            if(!op_2b()) goto l_def;            
            break;
        case 0x02c:
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "sub", "al", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x2d:
            if(prefix_66){
                iw = read_word();
                sprintf(buffer, FORMAT"%s, %s", "sub", "ax", hexbyte(iw));
            }
            else {
                id = read_dword();
                sprintf(buffer, FORMAT"%s, %s", "sub", "eax", hexbyte(id));
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x2e:
            seg_seg = "cs:";
            seg_ds = "cs:";
            seg_ss = "cs:";
            goto switch_start;
        case 0x30:
            if(!op_30()) goto l_def;            
            break;
        case 0x31:
            if(!op_31()) goto l_def;            
            break;
        case 0x32:
            if(!op_32()) goto l_def;            
            break;
        case 0x33:
            if(!op_33()) goto l_def;            
            break;
        case 0x34:
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s",
                "xor", "al", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x35:
            if(prefix_66){
                iw = read_word();
                sprintf(buffer, FORMAT"%s, %s", "xor", "ax", hexbyte(iw));
            }
            else {
                id = read_dword();
                sprintf(buffer, FORMAT"%s, %s", "xor", "eax", hexbyte(id));
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x36:
            seg_seg = "ss:";
            seg_ds = "ss:";
            seg_ss = "ss:";
            goto switch_start;
        case 0x38:
            if(!op_38()) goto l_def;            
            break;
        case 0x39:
            if(!op_39()) goto l_def;            
            break;
        case 0x3a:
            if(!op_3a()) goto l_def;            
            break;
        case 0x3b:
            if(!op_3b()) goto l_def;            
            break;
        case 0x3c:
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "cmp", "al", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x3d:
            if(prefix_66){
                iw = read_word();
                sprintf(buffer, FORMAT"%s, %s", "cmp", "ax", hexbyte(iw));
            }
            else {
                id = read_dword();
                sprintf(buffer, FORMAT"%s, %s", "cmp", "eax", hexbyte(id));
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x3e:
            seg_seg = "ds:";
            seg_ds = "ds:";
            seg_ss = "ds:";
            goto switch_start;
        case 0x40:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "inc", "eax");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x41:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "inc", "ecx");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x42:
            if(prefix_66){
                sprintf(buffer, FORMAT"%s", "inc", "dx");
            }
            else {
                sprintf(buffer, FORMAT"%s", "inc", "edx");
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x43:
            if(prefix_66){
                sprintf(buffer, FORMAT"%s", "inc", "bx");
            }
            else {
                sprintf(buffer, FORMAT"%s", "inc", "ebx");
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x45:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "inc", "ebp");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x46:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "inc", "esi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x47:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "inc", "edi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x48:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "dec", "eax");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x49:
            if(prefix_66){
                sprintf(buffer, FORMAT"%s", "dec", "cx");
            }
            else {
                sprintf(buffer, FORMAT"%s", "dec", "ecx");
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x4a:
            if(prefix_66){
                sprintf(buffer, FORMAT"%s", "dec", "dx");
            }
            else {
                sprintf(buffer, FORMAT"%s", "dec", "edx");
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x4b:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "dec", "ebx");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x4e:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "dec", "esi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x4f:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "dec", "edi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x50:
            if(operand_size == 32){
                sprintf(buffer, FORMAT"%s", "push", "eax");
            }
            else if(operand_size == 16){
                sprintf(buffer, FORMAT"%s", "push", "ax");
            }
            else goto l_def;
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x51:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "push", "ecx");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x52:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "push", "edx");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x53:
            if(operand_size == 32){
                sprintf(buffer, FORMAT"%s", "push", "ebx");
            }
            else if(operand_size == 16){
                sprintf(buffer, FORMAT"%s", "push", "bx");
            }
            else goto l_def;
            mark_instruction();// comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x55:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "push", "ebp");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x56:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "push", "esi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x57:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "push", "edi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x58:
            if(operand_size == 32){
                sprintf(buffer, FORMAT"%s", "pop", "eax");
            }
            else if(operand_size == 16){
                sprintf(buffer, FORMAT"%s", "pop", "ax");
            }
            else goto l_def;
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x59:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "pop", "ecx");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x5a:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "pop", "edx");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x5b:
            if(operand_size == 32){
                sprintf(buffer, FORMAT"%s", "pop", "ebx");
            }
            else if(operand_size == 16){
                sprintf(buffer, FORMAT"%s", "pop", "bx");
            }
            else goto l_def;
            mark_instruction();// comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x5d:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "pop", "ebp");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x5e:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "pop", "esi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x5f:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s", "pop", "edi");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x60:
            if(operand_size == 32){
                sprintf(buffer, FORMAT, "pushad");
            }
            else if(operand_size == 16){
                sprintf(buffer, FORMAT, "pusha");
            }
            else goto l_def;
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x61:
            if(operand_size == 32){
                sprintf(buffer, FORMAT, "popad");
            }
            else if(operand_size == 16){
                sprintf(buffer, FORMAT, "popa");
            }
            else goto l_def;
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x66:
            if(!op_66()) goto l_def;
            goto switch_start;
        case 0x67:
            switch(read_byte()){
            case 0xe3:
                rel8 = read_byte();

                mark_instruction();// comment_instruction();
                IDisasm.pushAddress(&current_va);

                // get jmp instruction offset
                current_va.offset += rel8;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"%s", "jcxz", getLabel(current_va.obj_n, current_va.offset));
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0x68:
            if(prefix_66) goto l_def;
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            id = read_dword();

            if(fx->size == 4){
                sprintf(buffer, FORMAT"%s%s",
                    "push", seg_seg, getLabel(fx->object_n, fx->target));
            }
            else {
                sprintf(buffer, FORMAT"dword %s", "push", hexbyte(id));
            }

            mark_instruction(); comment_instruction();
             // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x6a:
            if(prefix_66) goto l_def;
            ib = read_byte();
            sprintf(buffer, FORMAT"%s", "push", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x72:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jb", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x73:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jae", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x74:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "je", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x75:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jne", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x76:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jbe", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x77:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "ja", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x78:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "js", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x79:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jns", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x7c:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jl", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x7d:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jge", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x7e:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jle", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x7f:
            rel8 = read_byte();

            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);

            // get jmp instruction offset
            current_va.offset += rel8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jg", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0x80:
            if(!op_80()) goto l_def;
            break;
        case 0x81:
            if(!op_81()) goto l_def;      
            break;
        case 0x83:
            if(!op_83()) goto l_def;         
            break;
        case 0x84:
            if(!op_84()) goto l_def;
            break;
        case 0x85:
            if(!op_85()) goto l_def;
            break;
        case 0x86:
            switch(read_byte()){
            case 0xc1:
                sprintf(buffer, FORMAT"%s, %s",
                        "xchg", "cl", "al");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }            
            break;
        case 0x87:
            switch(read_byte()){
            case 0x05:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();      
                if(fx->size == 4){
                    sprintf(buffer, FORMAT"dword [%s%s], %s", 
                        "xchg", seg_ds, getLabel(fx->object_n, fx->target), "eax");
                }
                else {
                    goto l_def;
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x44:
                if(!prefix_66 && (read_byte() == 0x24)){
                    ib = read_byte();
                    sprintf(buffer, FORMAT"dword [%s%s+%s], %s",
                        "xchg", seg_ss, "esp", hexbyte(ib), "eax");
                }
                else {
                    goto l_def;
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }            
            break;
        case 0x88:  // MOV 
            if(!op_88()) goto l_def;
            break;
        case 0x89:  // MOV 
            if(!op_89()) goto l_def;
            break;
        case 0x8a:
            if(!op_8a()) goto l_def;
            break;
        case 0x8b:
            if(!op_8b()) goto l_def;
            break;
        case 0x8c:  // MOV 
            switch(read_byte()){
            case 0x05:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(fx->size == 4){
                    tmp_str = getLabel(fx->object_n, fx->target);
                }
                else {
                    tmp_str = hexbyte(id);
                }
                if(prefix_66){
                    sprintf(buffer, FORMAT"word [%s%s], %s",
                        "mov", seg_ds, tmp_str, "es");
                }
                else {
                    sprintf(buffer, FORMAT"dword [%s%s], %s",
                        "mov", seg_ds, tmp_str, "es");
                }
                
                mark_instruction(); comment_instruction();
                
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x1d:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(fx->size == 4){
                    tmp_str = getLabel(fx->object_n, fx->target);
                }
                else {
                    tmp_str = hexbyte(id);
                }

                if(prefix_66){
                    sprintf(buffer, FORMAT"[%s%s], %s", "mov",
                        seg_ds, tmp_str, "ds");
                }
                else {
                    sprintf(buffer, ";"FORMAT"[%s%s], %s", "mov",
                        seg_ds, tmp_str, "ds");
                }

                mark_instruction(); comment_instruction();
                
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc0:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ax", "es");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "eax", "es");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc1:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "cx", "es");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ecx", "es");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc3:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "bx", "es");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ebx", "es");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc8:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ax", "cs");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "eax", "cs");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc9:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "cx", "cs");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ecx", "cs");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd0:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ax", "ss");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "eax", "ss");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd8:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ax", "ds");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "eax", "ds");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd9:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "cx", "ds");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ecx", "ds");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xda:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "dx", "ds");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "edx", "ds");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xdb:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "bx", "ds");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ebx", "ds");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe0:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ax", "fs");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "eax", "fs");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe8:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ax", "gs");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "eax", "gs");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0x8d:
            if(!op_8d()) goto l_def;
            break;
        case 0x8e:  // MOV 
            switch(read_byte()){
            case 0x05:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(fx->size == 4){
                    tmp_str = getLabel(fx->object_n, fx->target);
                }
                else {
                    tmp_str = hexbyte(id);
                }
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, [%s%s]", "mov",
                        "es", seg_ds, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, [%s%s]", "mov",
                        "es", seg_ds, tmp_str);
                }
                
                mark_instruction(); comment_instruction();
                
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x06:
                if(address_size == 16){
                    iw = read_word();
                    sprintf(buffer, FORMAT"%s, [%s%s]", "mov",
                        "es", seg_ds, hexbyte(iw));
                }
                else goto l_def;
                
                mark_instruction();// comment_instruction();
                
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x1d:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(fx->size == 4){
                    tmp_str = getLabel(fx->object_n, fx->target);
                }
                else {
                    tmp_str = hexbyte(id);
                }
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, [%s%s]",
                        "mov", "ds", seg_ds, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, [%s%s]",
                        "mov", "ds", seg_ds, tmp_str);
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
      
            case 0xc0:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "ax");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "eax");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc1:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "cx");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "ecx");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc2:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "dx");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "edx");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc3:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "bx");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "es", "ebx");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd9:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ds", "cx");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ds", "ecx");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xda:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ds", "dx");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ds", "edx");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xdb:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ds", "bx");
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ds", "ebx");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
        
            default:
                goto l_def;
            }
            break;
        case 0x90:
            sprintf(buffer, FORMAT, "nop");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x96:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT"%s, %s", "xchg", "esi", "eax");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x9c:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT, "pushfd");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0x9d:
            if(prefix_66) goto l_def;
            sprintf(buffer, FORMAT, "popfd");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xa0:
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                current_va.offset += 4;
                sprintf(buffer, FORMAT"%s, byte [%s%s]", 
                    "mov", "al", seg_ds, getLabel(fx->object_n, fx->target));
            }
            else {
                sprintf(buffer, FORMAT"%s, byte [%s%08x]", 
                    "mov", "al", seg_ds, read_dword());
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xa1:
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                current_va.offset += 4;
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, word [%s%s]", 
                        "mov", "ax", seg_ds, getLabel(fx->object_n, fx->target));
                }
                else {
                    sprintf(buffer, FORMAT"%s, dword [%s%s]", 
                        "mov", "eax", seg_ds, getLabel(fx->object_n, fx->target));
                }
            }
            else {
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, word [%s%08x]", 
                        "mov", "ax", seg_ds, read_dword());
                }
                else {
                    sprintf(buffer, FORMAT"%s, dword [%s%08x]", 
                        "mov", "eax", seg_ds, read_dword());
                }
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xa2:
            if(prefix_66) goto l_def;
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                current_va.offset += 4;
                sprintf(buffer, FORMAT"[%s%s], %s", "mov", 
                    seg_ds, getLabel(fx->object_n, fx->target), "al");
            }
            else goto l_def;
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xa3:
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                current_va.offset += 4;
                if(prefix_66){
                    sprintf(buffer, FORMAT"[%s%s], %s", 
                        "mov", seg_ds, getLabel(fx->object_n, fx->target), "ax");
                }
                else {
                    sprintf(buffer, FORMAT"dword [%s%s], %s", 
                        "mov", seg_ds, getLabel(fx->object_n, fx->target), "eax");
                }
            }
            else {
                if(prefix_66){
                    sprintf(buffer, FORMAT"word [%s%08x], %s", 
                        "mov", seg_ds, read_dword(), "ax");
                }
                else {
                    sprintf(buffer, FORMAT"dword [%s%08x], %s", 
                        "mov", seg_ds, read_dword(), "eax");
                }
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xa4:
            if(prefix_66) goto l_def;
            if(rep_prefix[0]) rep_prefix = "rep ";
            //sprintf(buffer, "%s"FORMAT, rep_prefix, "movsb");
            sprintf(buffer, "%s"FORMAT, rep_prefix, "movsb");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xa5:
            if(rep_prefix[0]) rep_prefix = "rep ";
            if(prefix_66){
                sprintf(buffer, "%s"FORMAT, rep_prefix, "movsw");
            }
            else {
                sprintf(buffer, "%s"FORMAT, rep_prefix, "movsd");
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xa8:  // test AL, IB 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "test", "al", hexbyte(ib));
            mark_instruction();// comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xaa:
            if(rep_prefix[0]) rep_prefix = "rep ";
            sprintf(buffer, "%s"FORMAT, rep_prefix, "stosb");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xab:
            if(rep_prefix[0]) rep_prefix = "rep ";
            sprintf(buffer, "%s"FORMAT, rep_prefix, "stosd");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xac:
            if(rep_prefix[0]) rep_prefix = "rep ";
            sprintf(buffer, "%s"FORMAT, rep_prefix, "lodsb");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xad:
            if(rep_prefix[0]) rep_prefix = "rep ";
            if(prefix_66){
                sprintf(buffer, "%s"FORMAT, rep_prefix, "lodsw");
            }
            else {
                sprintf(buffer, "%s"FORMAT, rep_prefix, "lodsd");
            }
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xae:
            sprintf(buffer, "%s"FORMAT, rep_prefix, "scasb");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb0:  // MOV al, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "al", hexbyte(ib));
            mark_instruction();// comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb1:  // MOV cl, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "cl", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb2:  // MOV dl, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "dl", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb3:  // MOV bl, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "bl", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb4:  // MOV AH, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "ah", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb5:  // MOV CH, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "ch", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb6:  // MOV DH, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "dh", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb7:  // MOV BH, IMM8 
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "mov", "bh", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb8:
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                read_dword();
                tmp_str = getLabel(fx->object_n, fx->target);
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "ax", seg_seg, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "eax", seg_seg, tmp_str);
                }
            }
            else {
                if(prefix_66){
                    iw = read_word();
                    tmp_str = hexbyte(iw);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ax", tmp_str);
                }
                else {
                    id = read_dword();
                    tmp_str = hexbyte(id);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "eax", tmp_str);
                }
            }
            mark_instruction(); comment_instruction();
            
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xb9:
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                read_dword();
                tmp_str = getLabel(fx->object_n, fx->target);
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "cx", seg_seg, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "ecx", seg_seg, tmp_str);
                }
            }
            else {
                if(prefix_66){
                    imm16 = read_word();
                    tmp_str = hexbyte(imm16);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "cx", tmp_str);
                }
                else {
                    imm32 = read_dword();
                    tmp_str = hexbyte(imm32);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ecx", tmp_str);
                }
            }
            mark_instruction(); comment_instruction();
            
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xba:  // MOV EDX, IMM16/32 
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                read_dword();
                tmp_str = getLabel(fx->object_n, fx->target);
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "dx", seg_seg, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "edx", seg_seg, tmp_str);
                }
            }
            else {
                if(prefix_66){
                    imm16 = read_word();
                    tmp_str = hexbyte(imm16);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "dx", tmp_str);
                }
                else {
                    imm32 = read_dword();
                    tmp_str = hexbyte(imm32);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "edx", tmp_str);
                }
            }
            mark_instruction(); comment_instruction();
            
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xbb:  // MOV EBX, IMM16/32 
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                read_dword();
                tmp_str = getLabel(fx->object_n, fx->target);
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "bx", seg_seg, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "ebx", seg_seg, tmp_str);
                }
            }
            else {
                if(prefix_66){
                    imm16 = read_word();
                    tmp_str = hexbyte(imm16);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "bx", tmp_str);
                }
                else {
                    imm32 = read_dword();
                    tmp_str = hexbyte(imm32);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ebx", tmp_str);
                }
            }
            mark_instruction(); comment_instruction();
            
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xbd:  // MOV EBP, IMM16/32 
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                read_dword();
                tmp_str = getLabel(fx->object_n, fx->target);
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "bp", seg_seg, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "ebp", seg_seg, tmp_str);
                }
            }
            else {
                if(prefix_66){
                    imm16 = read_word();
                    tmp_str = hexbyte(imm16);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "bp", tmp_str);
                }
                else {
                    imm32 = read_dword();
                    tmp_str = hexbyte(imm32);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "ebp", tmp_str);
                }
            }
            mark_instruction(); comment_instruction();
            
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xbe:  // MOV ESI, IMM16/32 
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                read_dword();
                tmp_str = getLabel(fx->object_n, fx->target);
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "si", seg_seg, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "esi", seg_seg, tmp_str);
                }
            }
            else {
                if(prefix_66){
                    imm16 = read_word();
                    tmp_str = hexbyte(imm16);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "si", tmp_str);
                }
                else {
                    imm32 = read_dword();
                    tmp_str = hexbyte(imm32);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "esi", tmp_str);
                }
            }
            mark_instruction(); comment_instruction();
            
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xbf:  // MOV EDI, IMM16/32 
            fx = le_checkFixup(current_va.obj_n, current_va.offset);
            if(fx->size == 4){
                read_dword();
                tmp_str = getLabel(fx->object_n, fx->target);
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "di", seg_seg, tmp_str);
                }
                else {
                    sprintf(buffer, FORMAT"%s, %s%s",
                        "mov", "edi", seg_seg, tmp_str);
                }
            }
            else {
                if(prefix_66){
                    imm16 = read_word();
                    tmp_str = hexbyte(imm16);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "di", tmp_str);
                }
                else {
                    imm32 = read_dword();
                    tmp_str = hexbyte(imm32);
                    sprintf(buffer, FORMAT"%s, %s", "mov", "edi", tmp_str);
                }
            }
            mark_instruction(); comment_instruction();
            
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xc0:
            if(prefix_66) goto l_def;
            switch(read_byte()){
            case 0xc8:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "ror", "al", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe0:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "al", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe2:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "dl", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xc1:
            if(prefix_66) goto l_def;
            switch(read_byte()){
            case 0xca:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "ror", "edx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe0:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "eax", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe1:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "ecx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe2:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "edx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe3:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "ebx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe5:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "ebp", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe6:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "esi", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe7:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shl", "edi", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe8:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shr", "eax", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe9:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shr", "ecx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xea:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shr", "edx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xeb:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shr", "ebx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xee:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "shr", "esi", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xf8:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "sar", "eax", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xf9:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "sar", "ecx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xfa:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "sar", "edx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xfe:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "sar", "esi", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xc2:  // RET
            iw = read_word();
            sprintf(buffer, FORMAT"%s", "ret", hexbyte(iw));
            mark_instruction();// comment_instruction();
            break;
        case 0xc3:  // RET
            sprintf(buffer, FORMAT, "ret");
            mark_instruction();// comment_instruction();
            break;
        case 0xc6:
            switch(read_byte()){
            case 0x00:
                ib = read_byte();
                sprintf(buffer, FORMAT"byte [%s%s], %s",
                    "mov", seg_ds, "eax", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x01:
                ib = read_byte();
                sprintf(buffer, FORMAT"byte [%s%s], %s",
                    "mov", seg_ds, "ecx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x03:
                ib = read_byte();
                sprintf(buffer, FORMAT"byte [%s%s], %s",
                    "mov", seg_ds, "ebx", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x05:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(!prefix_66 && fx->size == 4){
                    ib = read_byte();
                    sprintf(buffer, FORMAT"byte [%s%s], %s", "mov", seg_ds, 
                        getLabel(fx->object_n, fx->target), hexbyte(ib));
                    mark_instruction(); comment_instruction();
                    // push next instruction offset to stack
                    IDisasm.pushAddress(&current_va);
                }
                else goto l_def;
                break;
            case 0x44:
                if(!prefix_66 && (read_byte() == 0x24)){
                    displacement_8 = read_byte();
                    ib = read_byte();
                    sprintf(buffer, FORMAT"byte [%s%s+%s], %s",
                        "mov", seg_ss, "esp", hexbyte(displacement_8), hexbyte(ib));
                }
                else {
                    goto l_def;
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x80:
                if(!prefix_66){
                    displacement_32 = read_dword();
                    ib = read_byte();
                    sprintf(buffer, FORMAT"byte [%s%s+%s], %s",
                        "mov", seg_ds, "eax", hexbyte(displacement_32), hexbyte(ib));
                }
                else {
                    goto l_def;
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xc7:
            switch(read_byte()){
            case 0x01:
                if(prefix_66){
                    iw = read_word();
                    sprintf(buffer, FORMAT"word [%s%s], %s", "mov",
                        seg_ds, "ecx", hexbyte(iw));
                }
                else goto l_def;
                break;
            case 0x05:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(fx->size == 4){
                    if(prefix_66){
                        iw = read_word();
                        sprintf(buffer, FORMAT"word [%s%s], %s", "mov", seg_ds, 
                            getLabel(fx->object_n, fx->target), hexbyte(iw));
                    }
                    else{
                        id = read_dword();
                        sprintf(buffer, FORMAT"dword [%s%s], %s", "mov", seg_ds, 
                            getLabel(fx->object_n, fx->target), hexbyte(id));
                    }
                    mark_instruction(); comment_instruction();
                    // push next instruction offset to stack
                    IDisasm.pushAddress(&current_va);
                }
                else goto l_def;
                break;
            case 0x82:
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(fx->size == 4){
                    if(prefix_66){
                        goto l_def;
                    }
                    else{
                        id = read_dword();
                        sprintf(buffer, FORMAT"[%s%s+%s], %s", "mov", seg_ds, 
                            "edx", getLabel(fx->object_n, fx->target), hexbyte(id));
                    }
                    mark_instruction(); comment_instruction();
                    // push next instruction offset to stack
                    IDisasm.pushAddress(&current_va);
                }
                else goto l_def;
                break;
            default:
                goto l_def;
            }
            break;
        case 0xcc:  // INT3
            sprintf(buffer, FORMAT"%s\t;%s", "db", hexbyte(0xcc), "int3");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xcd:  // INT ib
            ib = read_byte();
            sprintf(buffer, FORMAT"%s", "int", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xcf:  // IRET
            sprintf(buffer, FORMAT, "iret");
            mark_instruction();// comment_instruction();
            break;
        case 0xd0:
            if(prefix_66) goto l_def;
            switch(read_byte()){
            case 0xe8:
                sprintf(buffer, FORMAT"%s, %s", "shr",
                    "al", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xd1:
            switch(read_byte()){
            case 0xc8:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "ror",
                    "eax", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xca:
                if(operand_size == 32){
                    sprintf(buffer, FORMAT"%s, %s", "ror",
                        "edx", hexbyte(1));
                }
                else if(operand_size == 16){
                    sprintf(buffer, FORMAT"%s, %s", "ror",
                        "dx", hexbyte(1));
                }
                else goto l_def;
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd0:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "rcl",
                    "eax", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd2:
                if(operand_size == 32){
                    sprintf(buffer, FORMAT"%s, %s", "rcl",
                        "edx", hexbyte(1));
                }
                else if(operand_size == 16){
                    sprintf(buffer, FORMAT"%s, %s", "rcl",
                        "dx", hexbyte(1));
                }
                else goto l_def;
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xdb:
                if(!prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "rcr",
                    "bx", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe3:
                if(operand_size == 32){
                    sprintf(buffer, FORMAT"%s, %s", "shl",
                        "ebx", hexbyte(1));
                }
                else if(operand_size == 16){
                    sprintf(buffer, FORMAT"%s, %s", "shl",
                        "bx", hexbyte(1));
                }
                else goto l_def;
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe8:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "shr",
                    "eax", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe9:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "shr",
                    "ecx", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xeb:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "shr",
                    "ebx", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xf8:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "sar",
                    "eax", hexbyte(1));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xd2:
            switch(read_byte()){
            case 0xc0:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "rol",
                    "al", "cl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc8:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "ror",
                    "al", "cl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xd3:
            switch(read_byte()){
            case 0xe2:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "shl",
                    "edx", "cl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe3:
                if(!prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "shl",
                    "bx", "cl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe8:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s, %s", "shr",
                    "eax", "cl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xe4:  // IN ib
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "in", "al", hexbyte(ib));
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xe2:  // 
            displacement_8 = read_byte();
            mark_instruction();// comment_instruction();
            // get jmp instruction offset
            IDisasm.pushAddress(&current_va);
            current_va.offset += displacement_8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "loop", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0xe3:  // LOOP signExt 8
            displacement_8 = read_byte();
            mark_instruction();// comment_instruction();
            // get jmp instruction offset
            IDisasm.pushAddress(&current_va);
            current_va.offset += displacement_8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jecxz", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0xe6:  // OUT ib, al
            ib = read_byte();
            sprintf(buffer, FORMAT"%s, %s", "out", hexbyte(ib), "al");
            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);
            break;
        case 0xe8:  // CALL signExt 32
            displacement_32 = read_dword();
            mark_instruction();// comment_instruction();
			if(!le_checkLabel(current_va.obj_n, current_va.offset)){
               	IDisasm.pushAddress(&current_va);
			}
            current_va.offset += displacement_32;
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "call", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
            break;
        case 0xe9:  // JMP signExt 16/32
            if(address_size == 32){
                displacement_32 = read_dword();
                mark_instruction();// comment_instruction();
                // get jmp instruction offset
                current_va.offset += displacement_32;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jmp", getLabel(current_va.obj_n, current_va.offset));
            } 
            else if(address_size == 16){
                displacement_16 = read_word();
                mark_instruction();// comment_instruction();
                // get jmp instruction offset
                current_va.offset += displacement_16;
                // set label for jmp
                le_createLabel(current_va.obj_n, current_va.offset);
                sprintf(buffer, FORMAT"near %s", "jmp", getLabel(current_va.obj_n, current_va.offset));
            }
            else goto l_def;
            IDisasm.pushAddress(&current_va);
            break;
        case 0xeb:  // JMP signExt 8
            displacement_8 = read_byte();
            mark_instruction();// comment_instruction();
            // get jmp instruction offset
            current_va.offset += displacement_8;
            // set label for jmp
            le_createLabel(current_va.obj_n, current_va.offset);
            sprintf(buffer, FORMAT"%s", "jmp", getLabel(current_va.obj_n, current_va.offset));
            IDisasm.pushAddress(&current_va);
                break;
        case 0xec:  // IN al, dx
            sprintf(buffer, FORMAT"%s, %s", "in", "al", "dx");
            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);
            break;
        case 0xee:  // OUT dx, al
            sprintf(buffer, FORMAT"%s, %s", "out", "dx", "al");
            mark_instruction();// comment_instruction();
            IDisasm.pushAddress(&current_va);
            break;
        case 0xef:  // OUT dx, eax
            if(prefix_66){
                sprintf(buffer, FORMAT"%s, %s", "out", "dx", "ax");
            }
            else {
                sprintf(buffer, FORMAT"%s, %s", "out", "dx", "eax");
            }
            mark_instruction(); comment_instruction();
            IDisasm.pushAddress(&current_va);
            break;
        case 0xf2:
            rep_prefix = "repne ";
            goto switch_start;
        case 0xf3:
            rep_prefix = "repe ";
            goto switch_start;
        case 0xf6:
            if(prefix_66) goto l_def;
            switch(read_byte()){
            case 0x40:
                displacement_8 = read_byte();
                ib = read_byte();
                sprintf(buffer, FORMAT"byte [%s%s+%s], %s", "test",
                    seg_ds, "eax", hexbyte(displacement_8), hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x42:
                displacement_8 = read_byte();
                ib = read_byte();
                sprintf(buffer, FORMAT"byte [%s%s+%s], %s", "test",
                    seg_ds, "edx", hexbyte(displacement_8), hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x43:
                displacement_8 = read_byte();
                ib = read_byte();
                sprintf(buffer, FORMAT"byte [%s%s+%s], %s", "test",
                    seg_ds, "ebx", hexbyte(displacement_8), hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x44:
                if(!prefix_66 && (read_byte() == 0x24)){
                    displacement_8 = read_byte();
                    ib = read_byte();
                    sprintf(buffer, FORMAT"byte [%s%s+%s], %s",
                        "test", seg_ss, "esp", hexbyte(displacement_8), hexbyte(ib));
                }
                else {
                    goto l_def;
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x46:
                displacement_8 = read_byte();
                ib = read_byte();
                sprintf(buffer, FORMAT"byte [%s%s+%s], %s", "test",
                    seg_ds, "esi", hexbyte(displacement_8), hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc1:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "test", "cl", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc2:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "test", "dl", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc3:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "test", "bl", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc4:
                ib = read_byte();
                sprintf(buffer, FORMAT"%s, %s", "test", "ah", hexbyte(ib));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd0:
                sprintf(buffer, FORMAT"%s", "not", "al");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xdb:
                sprintf(buffer, FORMAT"%s", "neg", "bl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe2:
                sprintf(buffer, FORMAT"%s", "mul", "dl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe4:
                sprintf(buffer, FORMAT"%s", "mul", "ah");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xf7:
            switch(read_byte()){
            case 0x87:
                if(prefix_66){
                    displacement_32 = read_dword();
                    iw = read_word();
                    sprintf(buffer, FORMAT"word [%s%s+%s], %s", "test", 
                        seg_ds, "edi", hexbyte(displacement_32), hexbyte(iw));
                }
                else {
                    goto l_def;
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc6:
                if(operand_size == 32){
                    id = read_dword();
                    sprintf(buffer, FORMAT"%s, %s", "test", 
                        "edi", hexbyte(id));
                }
                else if(operand_size == 16) {
                    iw = read_word();
                    sprintf(buffer, FORMAT"%s, %s", "test", 
                        "si", hexbyte(iw));
                }
                else goto l_def;
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc7:
                if(operand_size == 32){
                    id = read_dword();
                    sprintf(buffer, FORMAT"%s, %s", "test", 
                        "edi", hexbyte(id));
                }
                else if(operand_size == 16){
                    iw = read_word();
                    sprintf(buffer, FORMAT"%s, %s", "test", 
                        "si", hexbyte(iw));
                }
                else goto l_def;
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd0:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "not", "eax");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd1:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "not", "ecx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd2:
                if(operand_size == 32){
                    sprintf(buffer, FORMAT"%s", "not", "edx");
                }
                else if(operand_size == 16){
                    sprintf(buffer, FORMAT"%s", "not", "dx");
                }
                else goto l_def;
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd3:
                if(!prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "not", "bx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd8:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "neg", "eax");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xd9:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s", "neg", "cx");
                }
                else {
                    sprintf(buffer, FORMAT"%s", "neg", "ecx");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xdf:
                if(prefix_66){
                    sprintf(buffer, FORMAT"%s", "neg", "di");
                }
                else {
                    sprintf(buffer, FORMAT"%s", "neg", "edi");
                }
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xe9:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "imul", "ecx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xea:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "imul", "edx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xf1:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "div", "ecx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xf3:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "div", "ebx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xf9:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "idiv", "ecx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xfb:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "idiv", "ebx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xfe:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "idiv", "esi");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xf8:  // CLC
            sprintf(buffer, FORMAT, "clc");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xf9:  // STC
            sprintf(buffer, FORMAT, "stc");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xfa:  // CLI
            sprintf(buffer, FORMAT, "cli");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xfb:  // STI
            sprintf(buffer, FORMAT, "sti");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xfc:  // CLD
            sprintf(buffer, FORMAT, "cld");
            mark_instruction(); comment_instruction();
            // push next instruction offset to stack
            IDisasm.pushAddress(&current_va);
            break;
        case 0xfe:
            if(prefix_66) goto l_def;
            switch(read_byte()){
            case 0x05:
                address_mode = 5;
                sprintf(buffer, FORMAT"byte %s",
                    "inc", mod_rm());
                mark_instruction();// comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc0:
                sprintf(buffer, FORMAT"%s", "inc", "al");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc1:
                sprintf(buffer, FORMAT"%s", "inc", "cl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc2:
                sprintf(buffer, FORMAT"%s", "inc", "dl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc4:
                sprintf(buffer, FORMAT"%s", "inc", "ah");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc6:
                sprintf(buffer, FORMAT"%s", "inc", "dh");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc7:
                sprintf(buffer, FORMAT"%s", "inc", "bh");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc8:
                sprintf(buffer, FORMAT"%s", "dec", "al");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xc9:
                sprintf(buffer, FORMAT"%s", "dec", "cl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0xca:
                sprintf(buffer, FORMAT"%s", "dec", "dl");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            default:
                goto l_def;
            }
            break;
        case 0xff:
            switch(read_byte()){
            case 0x04:
                if(prefix_66) goto l_def;
                if(read_byte() != 0x24) goto l_def;
                sprintf(buffer, FORMAT"dword [%s%s]",
                    "inc", seg_ss, "esp");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x05:
                address_mode = 5;
                if(operand_size == 32){
                    sprintf(buffer, FORMAT"dword %s",
                    "inc", mod_rm());
                }
                else if(operand_size == 16){
                    sprintf(buffer, FORMAT"word %s",
                    "inc", mod_rm());
                }
                else goto l_def;
                mark_instruction();// comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x12:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"dword [%s%s]",
                    "call", seg_ds, "edx");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
				//if(!le_checkLabel(current_va.obj_n, current_va.offset)){
                	IDisasm.pushAddress(&current_va);
				//}
                break;
            case 0x15:
                if(prefix_66) goto l_def;
                fx = le_checkFixup(current_va.obj_n, current_va.offset);
                id = read_dword();
                if(fx->size != 4) goto l_def;
                sprintf(buffer, FORMAT"dword [%s%s]",
                    "call", seg_ds, getLabel(fx->object_n, fx->target));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
				//if(!le_checkLabel(current_va.obj_n, current_va.offset)){
                	IDisasm.pushAddress(&current_va);
				//}
                break;
            case 0x17:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"dword [%s%s]",
                    "call", seg_ds, "edi");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                //if(!le_checkLabel(current_va.obj_n, current_va.offset)){
                    IDisasm.pushAddress(&current_va);
                //}
                break;
            case 0x44:
                if(prefix_66) goto l_def;
                if(read_byte() != 0x24) goto l_def;
                displacement_8 = read_byte();
                sprintf(buffer, FORMAT"dword [%s%s+%s]",
                    "inc", seg_ss, "esp", hexbyte(displacement_8));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x45:
                if(prefix_66) goto l_def;
                if(address_size != 16) goto l_def;
                ib = read_byte();
                sprintf(buffer, FORMAT"word [%s%s+%s]",
                    "inc", seg_ds, "di", hexbyte(ib));
                mark_instruction();// comment_instruction();
                // push next instruction offset to stack
                IDisasm.pushAddress(&current_va);
                break;
            case 0x53:
                if(prefix_66) goto l_def;
                displacement_8 = read_byte();
                sprintf(buffer, FORMAT"dword [%s%s+%s]",
                    "call", seg_ds, "ebx", hexbyte(displacement_8));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
				//if(!le_checkLabel(current_va.obj_n, current_va.offset)){
                	IDisasm.pushAddress(&current_va);
				//}
                break;
            case 0x94:
                if(prefix_66) goto l_def;
                if(read_byte() != 0x24) goto l_def;
                displacement_32 = read_dword();
                sprintf(buffer, FORMAT"[%s%s+%s]",
                    "call", seg_ss, "esp", hexbyte(displacement_32));
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
				//if(!le_checkLabel(current_va.obj_n, current_va.offset)){
                	IDisasm.pushAddress(&current_va);
				//}
                break;
            case 0xd0:
                if(prefix_66) goto l_def;
                sprintf(buffer, FORMAT"%s", "call", "eax");
                mark_instruction(); comment_instruction();
                // push next instruction offset to stack
				//if(!le_checkLabel(current_va.obj_n, current_va.offset)){
                	IDisasm.pushAddress(&current_va);
				//}
                break;
            default:
                goto l_def;
            }
            break;
        default:
        l_def:
            printf("[DISASM] Dont know how to disassemble next instruction ...\n");
            dump15();
            continue;
        }

        str_size = strlen(buffer);

        fseek(IDisasm.fd, disasm_ptr, SEEK_SET);
        fwrite(&str_size, 1, 1, IDisasm.fd);
        fwrite(buffer, str_size, 1, IDisasm.fd);
        disasm_ptr += 1 + str_size;
    }
#undef FORMAT
}