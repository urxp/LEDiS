#include"bin2inc.h"
#include<stdio.h>
#include<stdlib.h>



#define GLOBAL_STATS
#define GLOBAL_POSITIONS

#ifdef GLOBAL_STATS
	#include<sys/time.h>
#endif

extern dword fixups_counter;
extern object_info * ObjectMap;
extern FILE * fixup_fd;
extern DisasmInterface IDisasm;

dword GLOBAL_DB_MAX = 0x10;
#ifdef GLOBAL_POSITIONS
	dword GLOBAL_POSITIONS_INTERVAL = 0x080;
	dword GLOBAL_PAGE_SIZE = 0x1000;
#endif
const char * GLOBAL_LABEL_PREFIX = "$@";

#ifdef GLOBAL_STATS
struct timeval __global_timer, __local_timer;
qword global_timer, local_timer;

qword timeDiff(struct timeval * start){

	qword useconds0 = 1000000 * start->tv_sec + start->tv_usec;
    gettimeofday(&__local_timer, (void *)0);
	qword useconds1 = 1000000 * __local_timer.tv_sec + __local_timer.tv_usec;

	return useconds1 - useconds0;
}

char * formatTime(qword useconds){

	char * ft = calloc(32, 1);

	dword seconds0 = useconds / 1000000;
	dword mseconds0 = useconds / 1000 % 1000;
	dword useconds0 = useconds % 1000000;

	if(useconds < 10000){

		sprintf(ft, "%d.%03d ms", mseconds0, useconds0);

		return ft;
	}

	sprintf(ft, "%d.%03d s", seconds0, mseconds0);

	return ft;
}
#endif



char * getObjectSegmentMapName(dword object_n){

	return ObjectMap[object_n - 1].MapName;
}

char * getObjectMapName(dword object_n){

	return ObjectMap[object_n - 1].MapName;
}

dword getObjectSize(dword object_n){

	return ObjectMap[object_n - 1].size;
}

dword getObjectOffset(dword object_n){

	return ObjectMap[object_n - 1].offset;
}

dword getObjectSegmentBaseAddress(dword object_n){

	return ObjectMap[object_n - 1].RelBaseAddress;
}

boolean getEntryStatus(dword object_n, dword address){

	if(ObjectMap[object_n - 1].EntryAddress != -1){

		return boolean(address == -1)
		? boolean(1)
		: boolean(ObjectMap[object_n - 1].EntryAddress == address); 
	}

	return boolean(0);
}

dword getEntryAddress(dword object_n){

	if(getEntryStatus(object_n, -1)) return ObjectMap[object_n - 1].EntryAddress;

	return -1;
}

boolean hasBSS(dword object_n){

	return boolean(ObjectMap[object_n - 1].BSS);
}


char * formatAddress(dword value){

	char * addressStr = calloc(12, 1); 

	sprintf(addressStr, "%08x", value);

	return addressStr;
}




char * hexbyte(dword val){

	char * result = calloc(12, 1);
	char * result0 = calloc(12, 1);

	sprintf(result, "%x", val);

	if(val < 10) return result;

	while(val){

		if(((val > 15) && (val < 160))
		||(val < 10)){

			sprintf(result0, "%sh", result);
			sprintf(result, "%s", result0);
			return result;
		}
		
		val >>= 8;
	}

	sprintf(result0, "0%sh", result);
	sprintf(result, "%s", result0);
	
	return result;
}

char * getLabel(dword obj, dword offset){

	char * label = calloc(32, 1);

	sprintf(label, "%s%s", GLOBAL_LABEL_PREFIX, hexbyte(getObjectSegmentBaseAddress(obj) + offset));

	return label;
}

#ifdef GLOBAL_STATS
char * speed(dword bytes, qword us){

	char * bspeed = calloc(32, 1);

	dword Ki = 1024;
	dword KB = Ki;
	dword MB = Ki*KB;
	dword GB = Ki*MB;

	double seconds_inverse = 1000000.0 / us;
	double speed_bs = seconds_inverse * bytes;

	if(speed_bs < (double)KB){
		sprintf(bspeed, "%.2f B/s", speed_bs);	
		return bspeed;
	}

	if(speed_bs < (double)MB){
		sprintf(bspeed, "%.2f KB/s", speed_bs / KB);	
		return bspeed;
	}

	if(speed_bs < (double)GB){
		sprintf(bspeed, "%.2f MB/s", speed_bs / MB);	
		return bspeed;
	}

	sprintf(bspeed, "%.2f GB/s", speed_bs / GB);	
	return bspeed;
}
#endif





void insert_dups(FILE * fd, dword qms){

	if(qms > 0) fprintf(fd, "resb\t%s\n", hexbyte(qms));
}
















struct {

	FILE * 		fd;
	dword 		obj_n;
	dword 		i;
	dword 		db_written;
	dword 		page_number;
	pointer 	in_buff;
} le;




void fn_fixup(){ // fixup

	dword diff;
	fixup_struct * fixup;

	fixup = le_getFixup(le.obj_n, le.i);

	switch(fixup->size){
	case 1:
		fprintf(le.fd, "\ndb\t%s", getLabel(fixup->object_n, fixup->target));
		le.db_written++;
		break;
	case 2:
		if(fixup->type == 2){
			fprintf(le.fd, "\ndw\t%s", getObjectSegmentMapName(fixup->object_n));
		}
		else {
			fprintf(le.fd, "\ndw\t%s", getLabel(fixup->object_n, fixup->target));
		}
		le.i+=1;
		le.db_written = 0;
#ifdef GLOBAL_POSITIONS
		if(le.i % GLOBAL_PAGE_SIZE == 0) le.page_number++;
		if(le.i % GLOBAL_POSITIONS_INTERVAL == 0)
			fprintf(le.fd, "\n;%d:%s+1", le.page_number, formatAddress(getObjectSegmentBaseAddress(le.obj_n) + le.i));
#endif
		break;
	case 4:
		fprintf(le.fd, "\ndd\t%s", getLabel(fixup->object_n, fixup->target));
		le.i+=3;
		le.db_written = 0;
#ifdef GLOBAL_POSITIONS
		if(le.i % GLOBAL_PAGE_SIZE < 3) le.page_number++;
		diff = le.i % GLOBAL_POSITIONS_INTERVAL;
		if(diff < 3)
			fprintf(le.fd, "\n;%d:%s+%d", le.page_number, formatAddress(getObjectSegmentBaseAddress(le.obj_n) + le.i - diff), 3 - diff);
#endif			
		break;
	default:
		printf("[bin2inc] err invalid fixup size %d\n", fixup->size);
	}
}


void fn_nofixup(){

	char * dlmtr;

	dlmtr = (le.db_written % GLOBAL_DB_MAX != 0) ? "," : "\ndb\t";
	fprintf(le.fd, "%s%s", dlmtr, hexbyte(((byte *)le.in_buff)[le.i]));
	le.db_written++;
}


void (*f_fixup[2])(void) = { &fn_nofixup, &fn_fixup };

void fn_noinstruction(){

	f_fixup[!!(ObjectMap[le.obj_n - 1].IR[le.i].flags & 0x2)]();
}

void fn_instruction(){

	IDisasm.loadInstruction(ObjectMap[le.obj_n - 1].IR[le.i].data);

	if(!!(ObjectMap[le.obj_n - 1].IR[le.i].flags & 0x8)){
		// comment out instruction, put raw bytes instead
		fprintf(le.fd, "\n\t\t;%s", IDisasm.InstructionString);
		fn_noinstruction();
	}
	else{
		fprintf(le.fd, "\n\t\t%s", IDisasm.InstructionString);
		dword skip = (ObjectMap[le.obj_n - 1].IR[le.i].flags & 0xF0) >> 4;
		le.i += (skip - 1);
		le.db_written = 0;
	}
}

void (*f_instruction[2])(void) = { &fn_noinstruction, &fn_instruction };

void fn_nolabel(){

	f_instruction[!!(ObjectMap[le.obj_n - 1].IR[le.i].flags & 0x4)]();
}

void fn_label(){

	fprintf(le.fd, "\n%s:", getLabel(le.obj_n, le.i));
	le.db_written = 0;

	fn_nolabel();
}


void (*f_label[2])(void) = { &fn_nolabel, &fn_label };





void bin2inc_2(dword obj_n, char * section_name){
	printf("[bin2inc] generating %s.inc\n", section_name);


	char filename[64] = {0};

	
	
	

	dword buff_size, qms, bss_end;

	if(hasBSS(obj_n)){

		buff_size	= le_getSize() - getObjectOffset(obj_n);
		bss_end 	= getObjectSize(obj_n);
	}
	else {		
		buff_size 	= getObjectSize(obj_n);
		bss_end		= 0;	
	}

	sprintf(filename, "%s.inc", section_name);

	le.in_buff 			= le_getBuffer() + getObjectOffset(obj_n);
	le.fd				= fopen(filename, "w");
	le.db_written		= 0;
	le.page_number		= 0;
	le.obj_n 			= obj_n;

	fprintf(le.fd, ";OBJECT#%d", obj_n);

//#ifdef GLOBAL_STATS
//	gettimeofday(&__local_timer, (void *)0);
//#endif

	for(le.i = 0; le.i < buff_size; le.i++){

		
#ifdef GLOBAL_POSITIONS
		if(le.i % GLOBAL_PAGE_SIZE == 0) le.page_number++;

		if(le.i % GLOBAL_POSITIONS_INTERVAL == 0){
			
			fprintf(le.fd, "\n;%d:%s", le.page_number, formatAddress(getObjectSegmentBaseAddress(obj_n) + le.i));
			le.db_written = 0;
		}
#endif

		if(getEntryStatus(obj_n, le.i)){
		
			fprintf(le.fd, "\n..start:");
			le.db_written = 0;
		}


		f_label[ObjectMap[obj_n - 1].IR[le.i].flags & 0x1]();
	}

//#ifdef GLOBAL_STATS
//	local_timer = timeDiff(&__local_timer);
//	printf("          ... processed %u bytes in %s (%s)\n", buff_size, formatTime(local_timer), speed(buff_size, local_timer));
//#endif

	fclose(le.fd);

	if(bss_end != 0){

		sprintf(filename, "bss_%d.inc", obj_n);
		printf("[bin2inc] generating bss_%u.inc\n", obj_n);

		qms			= 0;
		le.fd		= fopen(filename, "w");

		fprintf(le.fd, ";UNINITIALIZED DATA\n");

//#ifdef GLOBAL_STATS
//		buff_size 	= bss_end - le.i;
//		gettimeofday(&__local_timer, (void *)0);
//#endif

		for(; le.i < bss_end; le.i++){

			if(le_checkLabel(obj_n, le.i)){

				insert_dups(le.fd, qms);
				qms = 0;

				fprintf(le.fd, "%s:\t", getLabel(obj_n, le.i));
			}

			qms++;
		}

//#ifdef GLOBAL_STATS
//		local_timer = timeDiff(&__local_timer);
//		printf("          ... processed %u bytes in %s (%s)\n", buff_size, formatTime(local_timer), speed(buff_size, local_timer));
//#endif

		insert_dups(le.fd, qms);
		fclose(le.fd);
	}



	double dis_ratio = 100.0 * (double)ObjectMap[obj_n - 1].DisBytes / (double)ObjectMap[obj_n - 1].size;

	printf("          ... disassembled %u/%u bytes (%.3f %%)\n", ObjectMap[obj_n - 1].DisBytes, ObjectMap[obj_n - 1].size, dis_ratio);
}

























































int main(int argc, char * argv[]){

	dword object_n;

	fixup_fd = fopen("$__fixups.tmp", "wb+");
	IDisasm.init();

#ifdef GLOBAL_STATS
	gettimeofday(&__global_timer, (void *)0);
#endif

    le_initLinearExecutable("RALLY.LE");

    printf("[bin2inc] generating fixups and labels\n");

    processFixups();

//#ifdef GLOBAL_STATS
//	local_timer = timeDiff(&__global_timer);
//	printf("          ... %d fixups in %s\n", fixups_counter, formatTime(local_timer));
//#endif


	// disassembling [TODO]
	IDisasm.disassemble();


	// output

	for(object_n = 1; object_n <= le_getNumberOfObjects(); object_n++){
		
		bin2inc_2(object_n, getObjectMapName(object_n));
	}

#ifdef GLOBAL_STATS
	global_timer = timeDiff(&__global_timer);
	printf("[bin2inc] total time %s\n", formatTime(global_timer));
#endif

	IDisasm.close();
	fclose(fixup_fd);
	//remove("$__fixups.tmp");

    return 0;
}