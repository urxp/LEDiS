#include"bin2inc.h"


boolean op_8d(void){

    address_mode = read_byte();

    if(address_mode == 0x40){
        signed_byte i8 = read_byte();
        if(i8 == 0){
            // lea eax, [eax + 0]
            //sprintf(ibuffer, "align %s",
            //    hexbyte(getAlignment(current_va.offset)));
            //mark_instruction();
        }
        else {
            sprintf(ibuffer, iFORMAT"%s, [%s+%s]",
                "lea", "eax", "eax", hexbyte(i8));

            mark_instruction();
        }

        IDisasm.pushAddress(&current_va);
        return boolean(1);
    }

    sprintf(ibuffer, iFORMAT"%s, %s", "lea", mod_reg(), mod_rm());

    mark_instruction();
    // push next instruction offset to stack
    IDisasm.pushAddress(&current_va);

    return boolean(1);
}